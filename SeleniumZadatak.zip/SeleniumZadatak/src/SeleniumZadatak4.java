import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumZadatak4 {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();  

		// Otvaranje stranice
		driver.get("https://www.seleniumeasy.com/test/table-data-download-demo.html");
		// Broj redova
		List<WebElement> rowCount = driver.findElements(By.xpath("//*[@id=\"example\"]/tbody/tr"));
		System.out.println("Broj redova: " + rowCount.size());
		// Broj kolona
		List<WebElement> columnCount = driver.findElements(By.xpath("//*[@id=\"example\"]/tbody/tr[1]/td"));
		System.out.println("Broj kolona: " + columnCount.size());

		int b = 0;
		// Unos i citanje liste
		for (int i = 1; i <= rowCount.size(); i++) {

			String name = driver.findElement(By.xpath("//*[@id=\"example\"]/tbody/tr[" + i + "]/td[1]")).getText();
			String position = driver.findElement(By.xpath("//*[@id=\"example\"]/tbody/tr[" + i + "]/td[2]")).getText();
			String office = driver.findElement(By.xpath("//*[@id=\"example\"]/tbody/tr[" + i + "]/td[3]")).getText();
			String brGodina = driver.findElement(By.xpath("//*[@id=\"example\"]/tbody/tr[" + i + "]/td[4]")).getText();
			String startDate = driver.findElement(By.xpath("//*[@id=\"example\"]/tbody/tr[" + i + "]/td[5]")).getText();
			String salary = driver.findElement(By.xpath("//*[@id=\"example\"]/tbody/tr[" + i + "]/td[6]")).getText();

			if (30 <= Integer.parseInt(brGodina) && Integer.parseInt(brGodina) <= 60) {
				System.out.println(name + ": " + position + " / " + office + " / " + startDate + " / " + salary);
				b++;
			}
		}
		System.out.println("Broj osoba izmedju 30 i 60 godina je: " + b + ".");

		driver.quit();
	}

}
