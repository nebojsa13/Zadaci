import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumZadatak1 {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String a = "Nebojsa R.";
		
		//Otvaranje stranice
		driver.get("http://www.globalsqa.com/demo-site/frames-and-windows/#iFrame");

		//Kucanje text-a unutar iframe-a
		driver.switchTo().frame("globalSqa");
		driver.findElement(By.id("s")).sendKeys(a, Keys.ENTER);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Verifikacija unetog teksta
		String s = driver.findElement(By.xpath("//*[@id=\"s\"]")).getAttribute("placeholder");

		System.out.println("Uneti tekst je: " + s); 
		System.out.println("Trazeni tekst je: " + a);
		if (s.equals(a)) {
			System.out.println("Uneti tekst je tacan.");
		} else {
			System.out.println("Uneti tekst nije tacan.");
		}
		driver.close();
	}
} 
