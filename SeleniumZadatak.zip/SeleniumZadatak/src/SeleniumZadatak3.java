import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumZadatak3 {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		// Otvaranje stranice
		driver.get("https://www.seleniumeasy.com/test/window-popup-modal-demo.html");

		// Verifikacija text-a na po�etnoj stranici
		String a = "Window popup Modal Example for Automation";
		String provera = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/h2")).getText();
		System.out.println("Uzeti naslov je: " + provera);
		System.out.println("Trazeni naslov je: " + a);
		if (provera.equals(a)) {
			System.out.println("Naslov se podudara."); 
		} else { 
			System.out.println("Naslov nije isti.");
		}

		// Klik na "Twitter" dugme
		WebElement twitter = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]/div/div[2]/div[1]/a"));
		twitter.click();

		// Maksimizovanje i zatvaranje novog prozora
		String parent = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();
		Iterator<String> I1 = s.iterator();
		while (I1.hasNext()) {
			String child_window = I1.next();
			if (!parent.equals(child_window)) {
				driver.switchTo().window(child_window);
				System.out.println(driver.switchTo().window(child_window).getTitle());
				driver.manage().window().maximize();
				driver.close();
			}
		}
	}
}
