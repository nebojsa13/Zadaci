import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumZadatak2 {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");

		String StartDate = "01/09/2020";
//        String EndDate ="05/12/2020";
		String startValidate = "1September 2020";

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		WebElement selectDateStart = driver.findElement(By.xpath("//*[@id=\"datepicker\"]/input[1]"));
		selectDateStart.sendKeys(StartDate);
		selectDateStart.click();

		WebElement startDay = driver.findElement(By.xpath("/html/body/div[3]/div[1]/table/tbody/tr[1]/td[3]"));
		WebElement startMonth = driver.findElement(By.xpath("/html/body/div[3]/div[1]/table/thead/tr[2]/th[2]"));
		System.out.println(startDay.getText() + " " + startMonth.getText());

		if (startValidate.equals(startDay.getText() + startMonth.getText())) {
			System.out.println("Datum je tacno unet.");
		} else
			System.out.println("Datum nije tacno unet.");
		driver.close();
	}

}
