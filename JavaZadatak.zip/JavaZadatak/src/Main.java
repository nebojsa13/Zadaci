import java.io.FileInputStream;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Main {
	
	public static void main(String[] args) throws BiffException, IOException {

		FileInputStream f = new FileInputStream("xls file\\podaci.xls");
		Workbook w = Workbook.getWorkbook(f);
		Sheet s = w.getSheet(0);
		System.out.println("------------------------- Pocetak -------------------------");

		for (int i = 1; i < s.getRows(); i++) {

			String Id = s.getCell(0, i).getContents();
			String ime = s.getCell(1, i).getContents();
			String Pozicija = s.getCell(2, i).getContents();
			double cenaRadnogSata = Integer.parseInt(s.getCell(3, i).getContents());
			int brojRadnihSati = Integer.parseInt(s.getCell(4, i).getContents());
			double bonus = Integer.parseInt(s.getCell(6, i).getContents());

			if (Pozicija.contentEquals("Devops")) {
				Devops d = new Devops(bonus, ime, brojRadnihSati, cenaRadnogSata);
				System.out.println(Id + ". " + d.getIme() + " - Plata = " + d.izracunajPlatu() + " RSD");

			} else if (Pozicija.contentEquals("Programer")) {
				double prekovremeniRad = Integer.parseInt(s.getCell(5, i).getContents());
				Programer p = new Programer(bonus, prekovremeniRad, ime, brojRadnihSati, cenaRadnogSata);
				System.out.println(Id + ". " + p.getIme() + " - Plata = " + p.izracunajPlatu() + " RSD");

			} else {
				System.out.println(Pozicija + " nije tacno uneta.");
			}
		}
		System.out.println("-------------------------- Kraj ---------------------------");
	}
}
